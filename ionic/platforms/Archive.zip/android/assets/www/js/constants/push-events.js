App.constant("PUSH_EVENTS", {
    notificationReceived: "push-notification-received",
    unreadPushs: "push-get-unreaded",
    readPushs: "push-mark-as-read"
});