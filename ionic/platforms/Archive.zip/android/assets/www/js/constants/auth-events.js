App.constant("AUTH_EVENTS", {
    loginSuccess: "auth-login-success",
    logoutSuccess: "auth-logout-success",
    notAuthenticated: "auth-not-authenticated"
});